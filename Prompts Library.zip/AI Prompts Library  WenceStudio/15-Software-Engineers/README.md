# 💻 Software Engineers

> **AI-powered coding assistance, code review, and technical documentation**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Code Reviewer](./code-reviewer.md) | ⭐⭐⭐ | ChatGPT, Claude | Review code quality |
| [Architecture Designer](./architecture-designer.md) | ⭐⭐⭐ | Claude | System design |
| [Debug Assistant](./debug-assistant.md) | ⭐⭐ | ChatGPT | Fix bugs |
| [Documentation Writer](./documentation-writer.md) | ⭐⭐ | ChatGPT | Write docs |
| [Refactoring Guide](./refactoring-guide.md) | ⭐⭐⭐ | ChatGPT, Claude | Improve code |

---

## 🎯 Category Overview

Software Engineering prompts help you:
- **Review** code for quality and bugs
- **Design** scalable architectures
- **Debug** complex issues
- **Document** code effectively
- **Refactor** for maintainability

---

## 💡 Pro Tips

1. **Include context** - More context = better help
2. **Specify language/framework** - Different best practices
3. **Use Claude for long files** - 200K context
4. **Request explanations** - Learn while you fix
