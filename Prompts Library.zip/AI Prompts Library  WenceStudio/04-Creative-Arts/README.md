# 🎨 Creative Arts

> **Unleash creativity with AI-powered writing, visual design, and artistic exploration**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Story Writer](./story-writer.md) | ⭐⭐ | Claude | Fiction & narrative |
| [Poetry Composer](./poetry-composer.md) | ⭐⭐ | Claude | Poetry in various styles |
| [Image Prompt Generator](./image-prompt-generator.md) | ⭐⭐ | ChatGPT | AI art prompts |
| [Creative Brainstormer](./creative-brainstormer.md) | ⭐⭐ | Claude, ChatGPT | Idea generation |

---

## 🎯 Category Overview

Creative Arts prompts help you:
- **Write** compelling stories and poetry
- **Generate** ideas for visual art
- **Brainstorm** creative concepts
- **Explore** different artistic styles

---

## 💡 Pro Tips

1. **Use Claude for narrative depth** - Superior character and story development
2. **Provide style references** - Authors, artists, or movements
3. **Iterate and refine** - Build on initial outputs
4. **Mix genres and styles** - Create unique combinations
