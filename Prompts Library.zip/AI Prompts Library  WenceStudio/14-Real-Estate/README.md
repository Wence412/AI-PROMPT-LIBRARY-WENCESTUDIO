# 🏠 Real Estate

> **AI-powered property analysis, market research, and client communication**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Property Analyzer](./property-analyzer.md) | ⭐⭐ | ChatGPT, Perplexity | Evaluate properties |
| [Listing Writer](./listing-writer.md) | ⭐⭐ | ChatGPT, Claude | Write property listings |
| [Market Researcher](./market-researcher.md) | ⭐⭐ | Perplexity | Market analysis |
| [Client Communicator](./client-communicator.md) | ⭐⭐ | Claude | Client emails & updates |

---

## 🎯 Category Overview

Real Estate prompts help you:
- **Analyze** investment properties
- **Write** compelling listings
- **Research** local markets
- **Communicate** with clients professionally

---

## 💡 Pro Tips

1. **Use Perplexity for market data** - Real-time information
2. **Provide property details** - Better analysis
3. **Include local context** - Markets vary significantly
4. **Request multiple versions** - A/B test listings
