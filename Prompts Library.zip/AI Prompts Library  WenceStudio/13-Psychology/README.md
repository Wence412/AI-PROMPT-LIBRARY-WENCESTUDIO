# 🧠 Psychology

> **AI-powered mental wellness support, behavioral insights, and therapeutic techniques**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [CBT Companion](./cbt-companion.md) | ⭐⭐ | Claude | Cognitive behavioral techniques |
| [Journaling Coach](./journaling-coach.md) | ⭐ | Claude | Reflective writing |
| [Mindfulness Guide](./mindfulness-guide.md) | ⭐ | Claude | Meditation & awareness |
| [Emotional Intelligence](./emotional-intelligence.md) | ⭐⭐ | Claude | EQ development |

---

## 🎯 Category Overview

Psychology prompts help you:
- **Apply** evidence-based techniques
- **Reflect** through guided journaling
- **Practice** mindfulness exercises
- **Develop** emotional awareness

---

## ⚠️ Important Disclaimer

> [!CAUTION]
> These prompts are for **educational and self-improvement purposes only**. They are not a substitute for professional mental health treatment. If you're experiencing mental health issues, please consult a licensed professional.

---

## 💡 Pro Tips

1. **Use Claude for sensitivity** - Nuanced emotional responses
2. **Be honest with yourself** - Better reflection leads to growth
3. **Journal regularly** - Consistency matters
4. **Combine with professional help** - AI supplements, not replaces
