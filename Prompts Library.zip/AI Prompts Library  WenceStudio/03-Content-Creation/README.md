# ✍️ Content Creation

> **Create compelling, high-converting content across all channels**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Blog Post Generator](./blog-post-generator.md) | ⭐⭐ | ChatGPT | Long-form articles |
| [Social Media Manager](./social-media-manager.md) | ⭐⭐ | ChatGPT, Claude | Multi-platform posts |
| [Email Newsletter](./email-newsletter.md) | ⭐⭐ | ChatGPT | Email campaigns |
| [SEO Content Optimizer](./seo-content-optimizer.md) | ⭐⭐⭐ | ChatGPT | Search optimization |
| [Video Script Writer](./video-script-writer.md) | ⭐⭐ | Claude | Video content |

---

## 🎯 Category Overview

Content creation prompts help you:
- **Generate** engaging content quickly
- **Optimize** for SEO and discoverability
- **Adapt** tone and style for different audiences
- **Repurpose** content across platforms

---

## 🔧 Techniques Used

- **Role Assignment**: Expert writer/marketer personas
- **Structured Output**: Formatted content templates
- **Few-Shot Examples**: Brand voice consistency
- **Chain-of-Thought**: Research → outline → draft workflow

---

## 💡 Pro Tips

1. **Provide brand voice guidelines** - Tone, banned words, examples
2. **Include target audience details** - Demographics, pain points
3. **Request multiple variations** - A/B test options
4. **Use ChatGPT for SEO** - Strong keyword integration
5. **Use Claude for storytelling** - Better narrative flow
