# 🚀 Entrepreneurs

> **AI-powered business strategy, planning, and growth tools for founders and business owners**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Business Plan Generator](./business-plan-generator.md) | ⭐⭐⭐ | ChatGPT | Full business plans |
| [Pitch Deck Creator](./pitch-deck-creator.md) | ⭐⭐ | ChatGPT, Claude | Investor presentations |
| [Market Research](./market-research.md) | ⭐⭐ | Perplexity, ChatGPT | Market analysis |
| [Competitor Analysis](./competitor-analysis.md) | ⭐⭐ | Perplexity | Competitive intelligence |
| [Startup Advisor](./startup-advisor.md) | ⭐⭐⭐ | Claude, ChatGPT | Strategic coaching |

---

## 🎯 Category Overview

Entrepreneurs prompts help you:
- **Plan** and structure your business
- **Pitch** effectively to investors
- **Research** markets and competitors
- **Strategize** for growth

---

## 💡 Pro Tips

1. **Combine with Perplexity** - Get real market data
2. **Iterate on plans** - Build incrementally
3. **Request investor perspective** - Ask AI to critique your pitch
4. **Use Claude for strategy** - Better strategic thinking
