# 📦 Product Managers

> **AI-powered product strategy, user story writing, and stakeholder communication**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [PRD Generator](./prd-generator.md) | ⭐⭐⭐ | ChatGPT | Product requirements |
| [User Story Writer](./user-story-writer.md) | ⭐⭐ | ChatGPT | Agile stories |
| [Feature Prioritizer](./feature-prioritizer.md) | ⭐⭐⭐ | ChatGPT, Claude | Roadmap decisions |
| [Roadmap Planner](./roadmap-planner.md) | ⭐⭐⭐ | ChatGPT | Strategic planning |
| [Stakeholder Communicator](./stakeholder-communicator.md) | ⭐⭐ | Claude | Executive updates |

---

## 🎯 Category Overview

Product Manager prompts help you:
- **Document** clear product requirements
- **Write** effective user stories
- **Prioritize** features strategically
- **Communicate** with stakeholders

---

## 💡 Pro Tips

1. **Provide customer context** - Better problem framing
2. **Include constraints** - Technical and business limitations
3. **Request alternatives** - Explore different approaches
4. **Use Claude for strategy** - Nuanced trade-off analysis
