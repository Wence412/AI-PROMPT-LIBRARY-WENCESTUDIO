# 📅 Meetings

> **AI-powered meeting productivity, summarization, and follow-up automation**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Meeting Summarizer](./meeting-summarizer.md) | ⭐⭐ | Copilot, ChatGPT | Transcript summaries |
| [Action Item Extractor](./action-item-extractor.md) | ⭐⭐ | ChatGPT | Task extraction |
| [Agenda Generator](./agenda-generator.md) | ⭐ | ChatGPT | Meeting prep |
| [Follow-up Composer](./follow-up-composer.md) | ⭐⭐ | ChatGPT, Claude | Post-meeting emails |

---

## 🎯 Category Overview

Meeting prompts help you:
- **Summarize** meeting discussions
- **Extract** action items and decisions
- **Prepare** effective agendas
- **Follow up** with stakeholders

---

## 💡 Pro Tips

1. **Use Copilot in Teams** - Native integration
2. **Provide full transcripts** - Better summaries
3. **Specify attendee roles** - Context matters
4. **Request formatted output** - Easy to share
