# 🔒 Cybersecurity

> **AI-powered security analysis, threat assessment, and incident response**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Threat Analyzer](./threat-analyzer.md) | ⭐⭐⭐ | ChatGPT | Analyze security threats |
| [Security Audit](./security-audit.md) | ⭐⭐⭐ | ChatGPT | Code/config review |
| [Incident Response](./incident-response.md) | ⭐⭐⭐ | ChatGPT | Handle security incidents |
| [Vulnerability Assessment](./vulnerability-assessment.md) | ⭐⭐⭐ | ChatGPT, Perplexity | Assess vulnerabilities |

---

## 🎯 Category Overview

Cybersecurity prompts help you:
- **Analyze** potential security threats
- **Audit** code and configurations
- **Respond** to security incidents
- **Assess** system vulnerabilities

---

## ⚠️ Important Disclaimer

> [!CAUTION]
> These prompts are for **educational and defensive purposes only**. Always follow responsible disclosure practices and applicable laws.

---

## 💡 Pro Tips

1. **Never include sensitive data** - Anonymize all examples
2. **Use for learning** - Understand attack patterns defensively
3. **Combine with Perplexity** - Get latest CVE information
4. **Verify recommendations** - Always validate with security experts
