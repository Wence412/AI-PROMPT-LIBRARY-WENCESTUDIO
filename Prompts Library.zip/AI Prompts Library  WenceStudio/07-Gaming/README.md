# 🎮 Gaming

> **AI-powered game design, narrative development, and gaming analysis tools**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Game Design Consultant](./game-design-consultant.md) | ⭐⭐⭐ | ChatGPT | Game mechanics & design |
| [Narrative Designer](./narrative-designer.md) | ⭐⭐⭐ | Claude | Story & world-building |
| [Game Review Analyzer](./game-review-analyzer.md) | ⭐⭐ | ChatGPT | Review synthesis |
| [Strategy Guide Creator](./strategy-guide-creator.md) | ⭐⭐ | ChatGPT | Gameplay guides |

---

## 🎯 Category Overview

Gaming prompts help you:
- **Design** game mechanics and systems
- **Write** compelling game narratives
- **Analyze** game reviews and feedback
- **Create** guides and strategic content

---

## 💡 Pro Tips

1. **Use Claude for narrative** - Superior worldbuilding
2. **Provide reference games** - "Like X meets Y"
3. **Iterate on mechanics** - Balance is complex
4. **Consider player psychology** - Motivation matters
