# 🎯 Coaching

> **AI-powered coaching prompts for personal and professional development**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Executive Coach](./executive-coach.md) | ⭐⭐⭐ | Claude, ChatGPT | Leadership development |
| [Life Coach](./life-coach.md) | ⭐⭐ | Claude | Personal growth & goals |
| [Career Coach](./career-coach.md) | ⭐⭐ | ChatGPT, Claude | Career advancement |
| [Habit Formation](./habit-formation.md) | ⭐⭐ | ChatGPT | Building lasting habits |

---

## 🎯 Category Overview

Coaching prompts create supportive AI interactions that:
- **Guide self-reflection** through powerful questions
- **Challenge assumptions** in a supportive way
- **Create accountability** with action plans
- **Develop strategies** for growth

---

## 🔧 Techniques Used

- **Role Assignment**: Expert coach personas with specific methodologies
- **Conversational Flow**: Multi-turn dialogue patterns
- **Socratic Questioning**: Guiding through questions, not answers
- **Framework Application**: ICF, GROW, SMART methodologies

---

## 💡 Pro Tips

1. **Be specific about methodology** - ICF, GROW, or solution-focused
2. **Use Claude for sensitive topics** - More nuanced emotional intelligence
3. **Build multi-session context** - Reference previous insights
4. **Request action items** - Always end with concrete next steps
