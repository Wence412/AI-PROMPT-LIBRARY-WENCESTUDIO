# 💼 Job Search

> **AI-powered career advancement, resume optimization, and interview preparation**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Resume Optimizer](./resume-optimizer.md) | ⭐⭐ | ChatGPT | ATS-optimized resumes |
| [Cover Letter Writer](./cover-letter-writer.md) | ⭐⭐ | Claude | Personalized applications |
| [Interview Coach](./interview-coach.md) | ⭐⭐ | ChatGPT, Claude | Interview preparation |
| [LinkedIn Optimizer](./linkedin-optimizer.md) | ⭐⭐ | ChatGPT | Profile enhancement |
| [Salary Negotiator](./salary-negotiator.md) | ⭐⭐⭐ | Claude | Negotiation strategy |

---

## 🎯 Category Overview

Job Search prompts help you:
- **Optimize** resumes for ATS systems
- **Write** compelling cover letters
- **Prepare** for interviews
- **Negotiate** better offers

---

## 💡 Pro Tips

1. **Include job descriptions** - Better tailoring
2. **Use Claude for narrative** - Compelling stories
3. **Request multiple variations** - Different approaches
4. **Practice with mock interviews** - Use conversational mode
