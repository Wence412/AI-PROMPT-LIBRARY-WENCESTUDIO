# 📚 Students & School

> **AI-powered learning assistance, study tools, and academic writing support**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Concept Explainer](./concept-explainer.md) | ⭐ | ChatGPT, Claude | Understand difficult topics |
| [Study Guide Creator](./study-guide-creator.md) | ⭐⭐ | ChatGPT | Exam preparation |
| [Essay Improver](./essay-improver.md) | ⭐⭐ | Claude | Improve writing |
| [Research Assistant](./research-assistant.md) | ⭐⭐ | Perplexity | Find sources |
| [Tutor](./tutor.md) | ⭐⭐ | ChatGPT, Claude | Practice problems |

---

## 🎯 Category Overview

Student prompts help you:
- **Understand** difficult concepts
- **Study** more effectively
- **Write** better essays
- **Research** with quality sources
- **Practice** with guided tutoring

---

## ⚠️ Academic Integrity

> [!IMPORTANT]
> Use AI as a **learning tool**, not to write your assignments. Always follow your institution's academic integrity policies.

---

## 💡 Pro Tips

1. **Ask for explanations** - "Explain like I'm 5" works
2. **Request Socratic method** - Learn through questions
3. **Use for study aids** - Flashcards, summaries
4. **Cite properly** - AI is a tool, not a source
