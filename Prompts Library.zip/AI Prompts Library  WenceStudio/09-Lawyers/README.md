# ⚖️ Lawyers

> **AI-powered legal analysis, document review, and research assistance**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Legal Document Analyzer](./legal-document-analyzer.md) | ⭐⭐⭐ | Claude | Contract analysis |
| [Contract Reviewer](./contract-reviewer.md) | ⭐⭐⭐ | Claude | Contract review |
| [Case Research Assistant](./case-research-assistant.md) | ⭐⭐⭐ | Perplexity, Claude | Legal research |
| [Legal Brief Drafter](./legal-brief-drafter.md) | ⭐⭐⭐ | Claude | Brief drafting |

---

## 🎯 Category Overview

Legal prompts help you:
- **Analyze** contracts and legal documents
- **Research** case law and precedents
- **Draft** legal briefs and memos
- **Identify** risks and issues

---

## ⚠️ Important Disclaimer

> [!CAUTION]
> These prompts are for **educational and preliminary analysis only**. AI is not a substitute for legal counsel. Always verify with qualified attorneys.

---

## 💡 Pro Tips

1. **Use Claude for long documents** - 200K context window
2. **Request citations** - Ask for specific clause references
3. **Combine with Perplexity** - Get current case law
4. **Define jurisdiction** - Laws vary by location
