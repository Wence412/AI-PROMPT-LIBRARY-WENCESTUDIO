# 📊 Visualizations

> **AI-powered data visualization, chart selection, and visual storytelling**

---

## 📁 Prompts in this Category

| Prompt | Difficulty | Best Platform | Use Case |
|--------|------------|---------------|----------|
| [Chart Recommender](./chart-recommender.md) | ⭐⭐ | ChatGPT | Choose right visualization |
| [Data Storyteller](./data-storyteller.md) | ⭐⭐⭐ | Claude, ChatGPT | Narrative from data |
| [Infographic Planner](./infographic-planner.md) | ⭐⭐ | ChatGPT | Design infographics |
| [Dashboard Designer](./dashboard-designer.md) | ⭐⭐⭐ | ChatGPT | Dashboard layouts |

---

## 🎯 Category Overview

Visualization prompts help you:
- **Select** the right chart types
- **Tell stories** with data
- **Plan** effective infographics
- **Design** actionable dashboards

---

## 💡 Pro Tips

1. **Start with the question** - What do you want the viewer to understand?
2. **Less is more** - Reduce clutter
3. **Consider your audience** - Technical vs. executive
4. **Lead with insight** - Not just data
